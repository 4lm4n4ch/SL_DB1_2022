package model;

public class ResultTable {
}
