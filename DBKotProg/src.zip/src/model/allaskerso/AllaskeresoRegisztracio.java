package model.allaskerso;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public  class AllaskeresoRegisztracio extends JFrame implements ActionListener {


private TextField nevTF;
private TextField jelszoTF;
private TextField emailTf;
private TextField telefonszamTF;
private TextField iskolaiVegzetseg;
private JButton regisztracioButton;
	private String sql_iskolaiVegzetseg;

	public AllaskeresoRegisztracio(){
  this.nevTF = new TextField( 50 );
	  this.jelszoTF = new TextField( 50 );
	  this.emailTf = new TextField( 50 );
	  this.telefonszamTF = new TextField( 50 );
	  this.iskolaiVegzetseg = new TextField( 50 );
	  this.regisztracioButton = new JButton( "Regisztracio" );
	  this.regisztracioButton.addActionListener(this);
}

	@Override
	public void actionPerformed(ActionEvent e) {
	String sql = "";
		if (e.getSource() == this.regisztracioButton) {

			if (nevTF.getText().equals("")|| nevTF.getText() == null){
				Alert alert = new Alert(Alert.AlertType.ERROR,"ADj meg nevet!", ButtonType.OK);
			}
			else if (jelszoTF.getText()== null || jelszoTF.getText().equals("")) {
				Alert alert = new Alert(Alert.AlertType.ERROR,"ADj meg jelszot!", ButtonType.OK);
			}
			else if (telefonszamTF.getText()== null || telefonszamTF.getText().equals("")){
				Alert alert = new Alert(Alert.AlertType.ERROR,"ADj meg telefonszamot!", ButtonType.OK);
			}
			else if (emailTf.getText()== null || emailTf.getText().equals("")){
				Alert alert = new Alert(Alert.AlertType.ERROR,"ADj meg Email cimet!", ButtonType.OK);
			}
			else if (iskolaiVegzetseg.getText()== null || iskolaiVegzetseg.getText().equals("")){
				Alert alert = new Alert(Alert.AlertType.ERROR,"ADj meg Iskolai vegzetseget!", ButtonType.OK);
			}
			else{

	sql= "INSERT INTO Allaskereso (email_cim, nev, jelszo, telefonszam) VALUES ('"+ emailTf.getText() +"', '"+ nevTF.getText() +"', '"+ jelszoTF.getText() +"', '"+ telefonszamTF.getText() +"');";
	sql_iskolaiVegzetseg ="INSERT INTO Iskolai_vegzettseg (email_cim, iskolai_vegzettseg) VALUES ('"+ emailTf.getText() +"', '"+ iskolaiVegzetseg.getText() +"');";

			}



		}


		}


	public void createGuiRegistration(){

    }



}
