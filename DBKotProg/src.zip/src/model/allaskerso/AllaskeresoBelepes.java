package model.allaskerso;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AllaskeresoBelepes extends JFrame implements ActionListener {

    private TextField emailTf;
    private TextField jelszoTf;
    private JButton bejelentkezesButton;

    public AllaskeresoBelepes(){
        this.emailTf = new TextField( 50 );
        this.jelszoTf = new TextField( 50 );
        this.bejelentkezesButton = new JButton( "Bejelentkezes" );
        this.bejelentkezesButton.addActionListener(this);
    }




    @Override
    public void actionPerformed(ActionEvent e) {
        String sql = "";


        if (emailTf.getText()== null || emailTf.getText().equals("")){
            Alert alert = new Alert(Alert.AlertType.ERROR,"ADj meg email cim!", ButtonType.OK);
        }
       else if (jelszoTf.getText()== null || jelszoTf.getText().equals("")) {
            Alert alert = new Alert(Alert.AlertType.ERROR,"ADj meg kérlek légyszyvesjelszo!", ButtonType.OK);
        }else{
            sql = "SELECT allaskereso.email, allaskereso.jelszo FROM Allaskereso WHERE allaskereso.email_cim LIKE '%"+ emailTf.getText() +"%' AND allaskereso.jelszo LIKE '%"+ jelszoTf.getText() +"%'";


        }





    }
}
