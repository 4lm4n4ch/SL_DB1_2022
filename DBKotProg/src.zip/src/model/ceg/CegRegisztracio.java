package model.ceg;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CegRegisztracio implements ActionListener {


    private TextField CegnevTF;
    private TextField jelszoTF;
    private TextField emailTf;
    private TextField telefonszamTF;
    private TextField kapcsolattartoNev;
    private JButton regisztracioButton;
    private String sql_iskolaiVegzetseg;



// ceg_nev, kapcsolattarto_email_cim, kapcsolattarto_nev, kapcsolattarto_telefonszam, kapcsolattarto_jelszo

    public CegRegisztracio(){
        this.CegnevTF = new TextField( 50 );
        this.jelszoTF = new TextField( 50 );
        this.emailTf = new TextField( 50 );
        this.telefonszamTF = new TextField( 50 );
        this.kapcsolattartoNev = new TextField( 50 );
        this.regisztracioButton = new JButton( "Regisztracio" );
        this.regisztracioButton.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String sql = "";
        if (e.getSource() == this.regisztracioButton) {

            if (CegnevTF.getText().equals("")|| CegnevTF.getText() == null){
                Alert alert = new Alert(Alert.AlertType.ERROR,"ADj meg nevet!", ButtonType.OK);
            }
            else if (jelszoTF.getText()== null || jelszoTF.getText().equals("")) {
                Alert alert = new Alert(Alert.AlertType.ERROR,"ADj meg jelszot!", ButtonType.OK);
            }
            else if (telefonszamTF.getText()== null || telefonszamTF.getText().equals("")){
                Alert alert = new Alert(Alert.AlertType.ERROR,"ADj meg telefonszamot!", ButtonType.OK);
            }
            else if (emailTf.getText()== null || emailTf.getText().equals("")){
                Alert alert = new Alert(Alert.AlertType.ERROR,"ADj meg Email cimet!", ButtonType.OK);
            }
            else if (kapcsolattartoNev.getText()== null || kapcsolattartoNev.getText().equals("")){
                Alert alert = new Alert(Alert.AlertType.ERROR,"ADj meg Iskolai vegzetseget!", ButtonType.OK);
            }
            else{
                sql= "INSERT INTO Ceg (ceg_nev, kapcsolattarto_email_cim, kapcsolattarto_nev, kapcsolattarto_telefonszam, kapcsolattarto_jelszo) VALUES ('"+ CegnevTF.getText() +"', '"+ emailTf.getText() +"', '"+ kapcsolattartoNev.getText() +"', '"+ telefonszamTF.getText() +"', '"+ jelszoTF.getText() +"');";
            }



        }


    }
}
