package model.ceg;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CegBejelentkezes implements ActionListener {

    private TextField emailTf;
    private TextField jelszoTf;
    private JButton bejelentkezesButton;

    public CegBejelentkezes(){
        this.emailTf = new TextField( 50 );
        this.jelszoTf = new TextField( 50 );
        this.bejelentkezesButton = new JButton( "Bejelentkezes" );
        this.bejelentkezesButton.addActionListener(this);
    }




    @Override
    public void actionPerformed(ActionEvent e) {
        String sql = "";


        if (emailTf.getText()== null || emailTf.getText().equals("")){
            Alert alert = new Alert(Alert.AlertType.ERROR,"ADj meg email cim!", ButtonType.OK);
        }
        else if (jelszoTf.getText()== null || jelszoTf.getText().equals("")) {
            Alert alert = new Alert(Alert.AlertType.ERROR,"ADj meg kérlek légyszyvesjelszo!", ButtonType.OK);
        }else{
            sql = "SELECT ceg.kapcsolattarto_email_cim,ceg.kapcsolattarto_jelszo FROM Ceg WHERE ceg.kapcsolattarto_email_cim LIKE '%"+ emailTf.getText() +"%' AND ceg.kapcsolattarto_jelszo LIKE '%"+ jelszoTf.getText() +"%'";


        }





    }
}
