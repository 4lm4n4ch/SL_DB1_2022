package model.jpanel;

import java.sql.*;

import javafx.collections.ObservableList;
import oracle.jdbc.pool.OracleDataSource;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
public class AllasAjanlatPanel extends JPanel {


    private JPanel allasAjanlat;
    private JTabbedPane tabbed_pane;
    private JPanel input_panel2;
    private JPanel output_panel2;
    private TextField name_field2;
    private Vector<String> column_names_vector2;

    private String choice_string2 = "allas";
    /**
     * lehet konstruktorba kell inicializálni watch out
     **/
    private DefaultTableModel table_model2;
    private ResultSet rs;
    private Statement stmt;

    public AllasAjanlatPanel() {
        this.allasAjanlat = new JPanel();
        setLayout(new BorderLayout());
        this.name_field2 = new TextField(50);
        this.table_model2 = new DefaultTableModel( column_names_vector2, 0 );
        this.column_names_vector2 = new Vector<>();

    }

    public void createGui() {
        tabbed_pane.addTab("Állás ajánlat", this.allasAjanlat);
        this.allasAjanlat.setLayout(new BorderLayout());
        this.allasAjanlat.add(input_panel2, BorderLayout.NORTH);
        this.allasAjanlat.add(output_panel2, BorderLayout.CENTER);

    }

    // Define event listeners
    public void actionPerformed(ActionEvent e) {


        /******************* Starting queries ********************/


        String sql = "";
        if (this.name_field2.getText().equals("") && !Objects.equals(choice_string2, "aktiv") && !Objects.equals(choice_string2, "nem aktiv")) {


            sql = "SELECT Ceg.ceg_nev, Allasajanlat.leiras, allasajanlat.berezesi_intervallum, allasajanlat.AKTIV  FROM Ceg, Allasajanlat WHERE Ceg.ceg_id = Allasajanlat.ceg_id";


        } else {
            if (choice_string2 == "ceg") {
                sql = "SELECT Ceg.ceg_nev, Allasajanlat.leiras, allasajanlat.berezesi_intervallum, allasajanlat.AKTIV  FROM Ceg, Allasajanlat WHERE Ceg.ceg_id = Allasajanlat.ceg_id AND Ceg.ceg_nev LIKE '%" + name_field2.getText() + "%' ORDER BY Ceg.ceg_nev";
            } else if (choice_string2 == "allas") {

                sql = "SELECT Ceg.ceg_nev, Allasajanlat.leiras, allasajanlat.berezesi_intervallum, allasajanlat.AKTIV  FROM Ceg, Allasajanlat WHERE Ceg.ceg_id = Allasajanlat.ceg_id AND allasajanlat.leiras LIKE '%" + name_field2.getText() + "%' ORDER BY ceg.ceg_nev";
            } else if (choice_string2 == "aktiv") {
                sql = "SELECT Ceg.ceg_nev, Allasajanlat.leiras, allasajanlat.berezesi_intervallum, allasajanlat.AKTIV  FROM Ceg, Allasajanlat WHERE Ceg.ceg_id = Allasajanlat.ceg_id AND allasajanlat.aktiv=1";
            } else if (choice_string2 == "nem aktiv") {
                sql = "SELECT Ceg.ceg_nev, Allasajanlat.leiras, allasajanlat.berezesi_intervallum, allasajanlat.AKTIV  FROM Ceg, Allasajanlat WHERE Ceg.ceg_id = Allasajanlat.ceg_id AND allasajanlat.aktiv=0";
            }


        }


        try {

            rs = stmt.executeQuery(sql);
            System.out.println(sql);
            System.out.println();
            //rs = stmt.executeQuery(sql)
            System.out.println(sql);
            // removing all rows from the table
            int count = table_model2.getRowCount();
            System.out.println(count);
            for (int i = count - 1; i >= 0; i--) {
                table_model2.removeRow(i);
            }
            repaint();

            while (rs.next()) {
                String str = "Nem aktív";
                if (rs.getInt(4) == 1) {
                    str = "aktív";
                }
                String row[] = {rs.getString(1), rs.getString(2), rs.getString(3), str};
                this.table_model2.addRow(row); // adding new row into the table
            }
            repaint();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

    }
}

