package model.jpanel;

import java.sql.*;

import javafx.collections.ObservableList;
import oracle.jdbc.pool.OracleDataSource;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class AdminPanel extends JPanel implements ActionListener, ItemListener{


    // Define UI components here (e.g., buttons, labels, text fields, etc.)
    private JPanel admin;
    private JTabbedPane tabbed_pane;
    private JPanel input_panel;
    private JPanel output_panel;
    private TextField name_field;
    private Vector<String> column_names_vector;
    private Choice field_choice;
    private JButton search_button;


    private String choice_string = "username"; /**lehet konstruktorba kell inicializálni watch out**/
    private DefaultTableModel table_model;
    private ResultSet rs;
    private Statement stmt;


    public AdminPanel() {
        this.admin = new JPanel();
        setLayout(new BorderLayout());
        this.name_field = new TextField(50);
        this.table_model = new DefaultTableModel( column_names_vector, 0 );
        this.column_names_vector = new Vector<>();
        this.output_panel = new JPanel();
        this.input_panel = new JPanel();
        this.column_names_vector.add( "username" );
        this.column_names_vector.add( "jelszo" );
        this.field_choice = new Choice();



    }

    public void createGui() {

        tabbed_pane.addTab("Admin", this.admin);

        this.admin.setLayout(new BorderLayout());
        this.admin.add(input_panel, BorderLayout.NORTH);
        this.admin.add(output_panel, BorderLayout.CENTER);
        this.input_panel.add(this.name_field);
        this.input_panel.setLayout( new GridLayout(3,3) );
        this.output_panel.setLayout( new BorderLayout() );
        this.input_panel.add( new Label("Content:") );
        this.input_panel.add( this.name_field );
        this.input_panel.add( new Label("Search in field:") );
        this.field_choice = new Choice();
        this.search_button = new JButton( "Search" );
        this.input_panel.add( this.field_choice );
        this.input_panel.add( this.search_button );

        this.field_choice.addItemListener(this);
        this.search_button.addActionListener(this);

        this.input_panel.setLayout( new GridLayout(3,3) );
        this.output_panel.setLayout( new BorderLayout() );



    }

    // Define event listeners
    public void actionPerformed(ActionEvent e) {


        /******************* Starting queries ********************/


        String sql = "";
        if (this.name_field.getText().equals("")) {


            sql = "SELECT * FROM ADMIN";


        } else {
            if (choice_string == "username") {
                sql = "SELECT * FROM admin WHERE username LIKE '" + name_field.getText() + "' ORDER BY username";
            } else if (choice_string == "jelszo") {
                sql = "SELECT * FROM admin WHERE jelszo LIKE '" + name_field.getText() + "' ORDER BY jelszo";
            }

        }


        try {

            rs = stmt.executeQuery(sql);
            System.out.println(sql);
            System.out.println();
            //rs = stmt.executeQuery(sql)
            System.out.println(sql);
            // removing all rows from the table
            int count = table_model.getRowCount();
            System.out.println(count);
            for (int i = count - 1; i >= 0; i--) {
                table_model.removeRow(i);
            }
            repaint();

            while (rs.next()) {
                String row[] = {rs.getString("username"), rs.getString("jelszo")};
                System.out.println(row.length);

                this.table_model.addRow(row); // adding new row into the table
            }
            repaint();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

    }
    public void itemStateChanged( ItemEvent e ) {
        this.choice_string = field_choice.getSelectedItem();
    }

}

